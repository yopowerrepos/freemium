﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace yp_learning_plugins.models.sample
{
    [DataContract]
    public class CustomAPIResponse
    {
        [JsonConstructor]
        public CustomAPIResponse()
        {
            this.Id = Guid.Empty;
        }

        [DataMember(Order = 1, Name = "dataverseid")]
        public Guid Id { get; set; }

        [DataMember(Order = 1, Name = "nome")]
        public string Name { get; set; }

        [DataMember(Order = 2, Name = "telefone")]
        public string Phone { get; set; }

        [DataMember(Order = 3, Name = "email")]
        public string Email { get; set; }
    }
}
