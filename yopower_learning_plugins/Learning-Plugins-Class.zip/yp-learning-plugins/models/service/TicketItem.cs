﻿using Microsoft.Xrm.Sdk;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using yp_learning_plugins.earlybound;

namespace yp_learning_plugins.models.service
{
    public class TicketItem
    {
        public TicketItem(EntityReference refTicket, yp_checklist_item item)
        {
            this.Ticket = refTicket;
            this.Reference = item.ToEntityReference();
            this.Question = item.yp_questionid;
            this.Title = item.yp_questionid != null && item.Contains("title") ? item.GetAttributeValue<AliasedValue>("title").Value.ToString() : "?";
            this.Required = item.yp_required ?? false;
            this.Order = item.yp_order ?? 99;
            this.Answered = false;
            this.Answer = string.Empty;
        }

        public TicketItem(EntityReference refTicket, yp_ticket_item item)
        {
            this.Ticket = refTicket;
            this.Reference = item.ToEntityReference();
            this.Question = item.GetAttributeValue<EntityReference>("question");
            this.Title = item.yp_question;
            this.Required = item.GetAttributeValue<bool>("required");
            this.Order = 0; // Ignore
            this.Answered = item.statuscode == yp_ticket_item_statuscode.Waiting ? false : true;
            this.Answer = item.yp_answer;
        }

        public TicketItem(TicketItem checklistItem, TicketItem ticketItem = null)
        {
            this.Ticket = checklistItem.Ticket;
            this.Reference = checklistItem.Reference;
            this.Question = checklistItem.Question;
            this.Title = checklistItem.Title;
            this.Required = checklistItem.Required;
            this.Order = checklistItem.Order;
            this.Answered = ticketItem != null ? ticketItem.Answered : false;
            this.Answer = ticketItem != null && !string.IsNullOrEmpty(ticketItem.Answer) ? ticketItem.Answer : string.Empty;
        }

        public yp_ticket_item NewItem()
        {
            return new yp_ticket_item()
            {
                yp_ticketid = Ticket,
                yp_referenceid = Reference,
                yp_question = Title,
                yp_answer = Answer
            };
        }

        public EntityReference Ticket { get; private set; }
        public EntityReference Reference { get; private set; }
        public EntityReference Question { get; private set; }
        public string Title { get; private set; }
        public bool Required { get; private set; }
        public int Order { get; private set; }
        public bool Answered { get; private set; }
        public string Answer { get; private set; }
    }
}
