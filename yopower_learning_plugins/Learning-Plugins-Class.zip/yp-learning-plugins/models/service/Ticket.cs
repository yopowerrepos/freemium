﻿using Microsoft.Xrm.Sdk;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;
using yp_learning_plugins.earlybound;

namespace yp_learning_plugins.models.service
{
    [DataContract]
    public class Ticket
    {
        public Ticket(yp_ticket record)
        {
            this.Code = record.yp_code.ToUpper();
            this.Title = record.yp_title.ToUpper();
            this.Subject = record.GetAttributeValue<AliasedValue>("subject").Value.ToString().ToUpper();
            this.Customer = record.GetAttributeValue<AliasedValue>("customer").Value.ToString().ToUpper();
            this.Status = record.statuscode.Value.GetHashCode();
            this.CreatedOn = record.CreatedOn.Value;
            if (record.statuscode == yp_ticket_statuscode.Closed)
                this.ClosedOn = record.ModifiedOn.Value;
            else
                this.ClosedOn = null;
        }

        [DataMember(Order = 1, Name = "code")]
        public string Code;
        [DataMember(Order = 2, Name = "title")]
        public string Title;
        [DataMember(Order = 3, Name = "subject")]
        public string Subject;
        [DataMember(Order = 4, Name = "customer")]
        public string Customer;
        [DataMember(Order = 5, Name = "status")]
        public int Status;
        [DataMember(Order = 6, Name = "createdon")]
        public DateTime CreatedOn;
        [DataMember(Order = 7, Name = "closedon")]
        public DateTime? ClosedOn;
    }
}
