﻿using Microsoft.Xrm.Sdk;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;
using yp_learning_plugins.earlybound;

namespace yp_learning_plugins.models.service
{
    [DataContract]
    public class GetTicketsResponse
    {
        public GetTicketsResponse(EntityCollection tickets)
        {
            if (tickets.Entities.Count > 0)
                this.Tickets = tickets.Entities.Select(s => new Ticket(s.ToEntity<yp_ticket>())).ToList();
            else
                this.Tickets = new List<Ticket>();
        }

        [DataMember(Order = 1, Name = "tickets")]
        public List<Ticket> Tickets { get; set; }
    }
}
