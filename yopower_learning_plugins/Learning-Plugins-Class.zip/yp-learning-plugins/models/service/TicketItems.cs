﻿using Microsoft.Xrm.Sdk;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using yp_learning_plugins.earlybound;

namespace yp_learning_plugins.models.service
{
    public class TicketItems
    {
        public TicketItems(EntityReference refTicket, List<yp_checklist_item> checklistItems)
        {
            this.FactoryNewItems(refTicket, checklistItems);
        }

        public TicketItems(EntityReference refTicket, List<yp_ticket_item> ticketItems)
        {
            this.FactoryExistingItems(refTicket, ticketItems);
        }

        private void FactoryNewItems(EntityReference refTicket, List<yp_checklist_item> checklistItems)
        {
            var items = checklistItems
                .Select(s => new TicketItem(refTicket, s))
                .ToList();

            // 'Distinct' by Reference with the Required is the Priority
            var distinct = items
                .OrderByDescending(i => i.Required)
                .GroupBy(i => i.Question.Id)
                .Select(g => g.First());

            this.Models = distinct.Select(s => s).ToList();
            this.Items = this.Models.Select(s => s.NewItem()).ToList();
        }

        private void FactoryExistingItems(EntityReference refTicket, List<yp_ticket_item> ticketItems)
        {
            this.Models = ticketItems
                .Select(s => new TicketItem(refTicket, s))
                .ToList();

            this.Items = this.Models.Select(s => s.NewItem()).ToList();
        }

        public List<TicketItem> Models { get; private set; }
        public List<yp_ticket_item> Items { get; private set; }
    }
}
