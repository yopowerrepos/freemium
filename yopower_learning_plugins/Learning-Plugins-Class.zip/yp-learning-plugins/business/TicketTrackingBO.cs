﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.PluginTelemetry;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using yp_learning_plugins.earlybound;

namespace yp_learning_plugins.business
{
    public class TicketTrackingBO : BaseBusiness
    {
        public TicketTrackingBO(IOrganizationService service, IOrganizationService serviceAdmin, IServiceEndpointNotificationService notificationService, ITracingService tracingService, ILogger logger) : base(service, serviceAdmin, notificationService, tracingService, logger)
        {
        }
    }
}
