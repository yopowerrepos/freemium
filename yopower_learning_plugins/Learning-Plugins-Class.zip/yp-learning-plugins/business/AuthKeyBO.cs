﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.PluginTelemetry;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using yp_learning_plugins.earlybound;

namespace yp_learning_plugins.business
{
    public class AuthKeyBO : BaseBusiness
    {
        public AuthKeyBO(IOrganizationService service, IOrganizationService serviceAdmin, IServiceEndpointNotificationService notificationService, ITracingService tracingService, ILogger logger) : base(service, serviceAdmin, notificationService, tracingService, logger)
        {
        }

        /// <summary>
        /// Generate a new key
        /// </summary>
        /// <param name="target"></param>
        public void NewKey(yp_customapi_authkey target)
        {
            target.yp_key = CreateMD5(Guid.NewGuid().ToString());
        }

        /// <summary>
        /// Get the Auth Key Policy
        /// </summary>
        /// <param name="key">Key</param>
        /// <returns>Authorization</returns>
        public yp_customapi_authkey GetAuthKeyPolicy(string key, Guid appId)
        {
            using (var orgContext = new CrmServiceContext(this.ServiceAdmin))
            {
                return orgContext.yp_customapi_authkeySet
                    .Where(w => w.yp_key == key
                        && w.yp_appregistrationid != null
                        && w.yp_appregistrationid.Id == appId
                        && w.statuscode == yp_customapi_authkey_statuscode.Active)
                    .Select(s => new yp_customapi_authkey()
                    {
                        yp_ticket_filter_policy = s.yp_ticket_filter_policy,
                        yp_due_date = s.yp_due_date
                    })
                    .FirstOrDefault();
            }
        }

        private string CreateMD5(string input)
        {
            using (MD5 md5 = MD5.Create())
            {
                byte[] inputBytes = Encoding.ASCII.GetBytes(input);
                byte[] hashBytes = md5.ComputeHash(inputBytes);

                StringBuilder sb = new StringBuilder();
                for (int i = 0; i < hashBytes.Length; i++)
                {
                    sb.Append(hashBytes[i].ToString("X2"));
                }
                return sb.ToString();
            }
        }
    }
}
