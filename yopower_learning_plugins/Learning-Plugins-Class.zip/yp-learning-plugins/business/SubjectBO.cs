﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.PluginTelemetry;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Security.Cryptography.Xml;
using System.Text;
using System.Threading.Tasks;
using yp_learning_plugins.earlybound;
using yp_learning_plugins.models.service;

namespace yp_learning_plugins.business
{
    public class SubjectBO : BaseBusiness
    {
        public SubjectBO(IOrganizationService service, IOrganizationService serviceAdmin, IServiceEndpointNotificationService notificationService, ITracingService tracingService, ILogger logger) : base(service, serviceAdmin, notificationService, tracingService, logger)
        {
        }
    }
}
