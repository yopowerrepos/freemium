﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Metadata;
using Microsoft.Xrm.Sdk.PluginTelemetry;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace yp_learning_plugins.business
{
    public class MetadataBO : BaseBusiness
    {
        public MetadataBO(IOrganizationService service, IOrganizationService serviceAdmin, IServiceEndpointNotificationService notificationService, ITracingService tracingService, ILogger logger) : base(service, serviceAdmin, notificationService, tracingService, logger)
        {
        }

        public EnumAttributeMetadata GetOptions(string table, string column)
        {
            var request = new RetrieveAttributeRequest
            {
                EntityLogicalName = table,
                LogicalName = column,
                RetrieveAsIfPublished = true
            };

            var response = (RetrieveAttributeResponse)this.ServiceAdmin.Execute(request);
            return (EnumAttributeMetadata)response.AttributeMetadata;
        }
    }
}
