﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.PluginTelemetry;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using yp_learning_plugins.earlybound;

namespace yp_learning_plugins.business
{
    public class SampleBO : BaseBusiness
    {
        public SampleBO(IOrganizationService service, IOrganizationService serviceAdmin, IServiceEndpointNotificationService notificationService, ITracingService tracingService, ILogger logger) : base(service, serviceAdmin, notificationService, tracingService, logger)
        {
        }

        public void CalcXYZ(yp_sample target, yp_sample image = null)
        {
            if (image == null)
                image = new yp_sample();

            int x = 0;
            if (target.Contains(yp_sample.Fields.yp_x))
                x = target.yp_x ?? 0;
            else if (image.Contains(yp_sample.Fields.yp_x))
                x = image.yp_x ?? 0;

            int y = 0;
            if (target.Contains(yp_sample.Fields.yp_y))
                y = target.yp_y ?? 0;
            else if (image.Contains(yp_sample.Fields.yp_y))
                y = image.yp_y ?? 0;

            target.yp_z = x + y;
        }
    }
}
