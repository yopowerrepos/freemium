﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.PluginTelemetry;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using yp_learning_plugins.earlybound;
using yp_learning_plugins.models.sample;
using yp_learning_plugins.statics;

namespace yp_learning_plugins.business.sample
{
    public class CustomAPIBO : BaseBusiness
    {
        public CustomAPIBO(IOrganizationService service, IOrganizationService serviceAdmin, IServiceEndpointNotificationService notificationService, ITracingService tracingService, ILogger logger) : base(service, serviceAdmin, notificationService, tracingService, logger)
        {
        }

        /// <summary>
        /// Get Customer Info
        /// </summary>
        /// <param name="document">Document (CNPJ)</param>
        public CustomAPIResponse GetCustomerData(string document, bool upsert = false)
        {
            var endpoint = this.RetrieveEnvironmentVariableValue("yp_fake_endpoint").ToString();
            var httpRequest = HttpRequestHelper.CreateWebRequest($"{endpoint}{document}");
            var httpResponse = HttpRequestHelper.ExecuteRequest<CustomAPIResponse>(httpRequest) as CustomAPIResponse;

            if (upsert)
            {
                var request = new UpsertRequest()
                {
                    Target = new Entity("account")
                    {
                        KeyAttributes = new KeyAttributeCollection()
                        {
                            { "accountnumber", document }
                        },
                        Attributes = new AttributeCollection()
                        {
                            { "name", httpResponse.Name.ToUpper() },
                            { "emailaddress1", httpResponse.Email.ToUpper() },
                            { "telephone1", httpResponse.Phone.ToUpper() }
                        }
                    }
                };

                var response = (UpsertResponse)this.Service.Execute(request);
                httpResponse.Id = response.Target.Id;
            }

            return httpResponse;
        }
    }
}
