﻿using Microsoft.Xrm.Sdk;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using yp_learning_plugins.business;
using yp_learning_plugins.earlybound;

namespace yp_learning_plugins.plugins.authkey
{
    public class PreOperation : PluginBase
    {
        public PreOperation(string unsecureConfiguration, string secureConfiguration) : base(typeof(PreOperation))
        {
        }

        protected override void ExecuteDataversePlugin(ILocalPluginContext localPluginContext)
        {
            var context = localPluginContext.PluginExecutionContext;
            var business = new AuthKeyBO(
                localPluginContext.PluginUserService,
                localPluginContext.PluginAdminImpersonatedService,
                localPluginContext.NotificationService,
                localPluginContext.TracingService,
                localPluginContext.Logger);

            if (context.InputParameters.Contains("Target") && context.InputParameters["Target"] is Entity)
            {
                var target = ((Entity)context.InputParameters["Target"]).ToEntity<yp_customapi_authkey>();
                if ("create".Equals(context.MessageName, StringComparison.InvariantCultureIgnoreCase))
                    business.NewKey(target);
            }
        }
    }
}