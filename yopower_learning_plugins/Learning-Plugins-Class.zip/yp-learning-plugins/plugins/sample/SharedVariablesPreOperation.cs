﻿using Microsoft.Xrm.Sdk;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace yp_learning_plugins.plugins.sample
{
    internal class SharedVariablesPreOperation : PluginBase
    {
        public SharedVariablesPreOperation(string unsecureConfiguration, string secureConfiguration) : base(typeof(PreValidation))
        {
        }

        protected override void ExecuteDataversePlugin(ILocalPluginContext localPluginContext)
        {
            var context = localPluginContext.PluginExecutionContext;
            Guid contact = new Guid("{74882D5C-381A-4863-A5B9-B8604615C2D0}");
            context.SharedVariables.Add("PrimaryContact", (Object)contact.ToString());
        }
    }

    internal class SharedVariablesPostOperation : PluginBase
    {
        public SharedVariablesPostOperation(string unsecureConfiguration, string secureConfiguration) : base(typeof(PreValidation))
        {
        }

        protected override void ExecuteDataversePlugin(ILocalPluginContext localPluginContext)
        {
            var context = localPluginContext.PluginExecutionContext;

            if (context.SharedVariables.Contains("PrimaryContact"))
            {
                Guid contact = new Guid((string)context.SharedVariables["PrimaryContact"]);
            }
        }
    }
}
