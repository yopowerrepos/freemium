﻿using Microsoft.Xrm.Sdk;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace yp_learning_plugins.plugins.sample
{
    public class PreOperation : PluginBase
    {
        public PreOperation(string unsecureConfiguration, string secureConfiguration) : base(typeof(PreValidation))
        {
        }

        protected override void ExecuteDataversePlugin(ILocalPluginContext localPluginContext)
        {
            var context = localPluginContext.PluginExecutionContext;

            if (context.InputParameters.Contains("Target") && context.InputParameters["Target"] is Entity)
            {
                var contact = (Entity)context.InputParameters["Target"];

                var task = new Entity("task");
                task["subject"] = "CRIADO VIA PG PRE-OPERATION";
                localPluginContext.PluginUserService.Create(task);

                // throw new InvalidPluginExecutionException(OperationStatus.Failed, "EXCEÇÃO NA THREAD PRE-OPERATION");
            }
        }
    }
}
