﻿using Microsoft.Xrm.Sdk;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace yp_learning_plugins.plugins.sample
{
    public class UnboundAction : PluginBase
    {
        public UnboundAction() : base(typeof(UnboundAction))
        {
        }

        protected override void ExecuteDataversePlugin(ILocalPluginContext localPluginContext)
        {
            var context = localPluginContext.PluginExecutionContext;

            var document = context.InputParameters["document"].ToString();

            // Regex - Somente Números
            document = Regex.Replace(document, "[^0-9]", "");

            // Validação
            var valido = false;
            if (document.Length == 11)
                valido = ValidarCPF(document);
            else if (document.Length == 14)
                valido = ValidarCNPJ(document);
            else
                valido = false;

            context.OutputParameters["valid"] = valido;
        }

        private static bool ValidarCPF(string cpf)
        {
            // Verifica se todos os dígitos são iguais
            if (new string(cpf[0], cpf.Length) == cpf)
                return false;

            // Calcula o primeiro dígito verificador
            int soma = 0;
            for (int i = 0; i < 9; i++)
                soma += (cpf[i] - '0') * (10 - i);

            int resto = soma % 11;
            int primeiroDigitoVerificador = (resto < 2) ? 0 : 11 - resto;

            // Verifica o primeiro dígito verificador
            if (cpf[9] - '0' != primeiroDigitoVerificador)
                return false;

            // Calcula o segundo dígito verificador
            soma = 0;
            for (int i = 0; i < 10; i++)
                soma += (cpf[i] - '0') * (11 - i);

            resto = soma % 11;
            int segundoDigitoVerificador = (resto < 2) ? 0 : 11 - resto;

            // Verifica o segundo dígito verificador
            if (cpf[10] - '0' != segundoDigitoVerificador)
                return false;

            return true;
        }

        public static bool ValidarCNPJ(string cnpj)
        {
            // Verifica se todos os dígitos são iguais
            if (new string(cnpj[0], cnpj.Length) == cnpj)
                return false;

            // Matrizes de multiplicação para os cálculos
            int[] multiplicador1 = new int[12] { 5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2 };
            int[] multiplicador2 = new int[13] { 6, 5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2 };

            // Calcula o primeiro dígito verificador
            int soma = 0;
            for (int i = 0; i < 12; i++)
                soma += (cnpj[i] - '0') * multiplicador1[i];

            int resto = soma % 11;
            int primeiroDigitoVerificador = (resto < 2) ? 0 : 11 - resto;

            // Verifica o primeiro dígito verificador
            if (cnpj[12] - '0' != primeiroDigitoVerificador)
                return false;

            // Calcula o segundo dígito verificador
            soma = 0;
            for (int i = 0; i < 13; i++)
                soma += (cnpj[i] - '0') * multiplicador2[i];

            resto = soma % 11;
            int segundoDigitoVerificador = (resto < 2) ? 0 : 11 - resto;

            // Verifica o segundo dígito verificador
            if (cnpj[13] - '0' != segundoDigitoVerificador)
                return false;

            return true;
        }
    }
}
