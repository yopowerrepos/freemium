﻿using Microsoft.Xrm.Sdk;
using System.IdentityModel.Metadata;
using System.Linq;
using System.Text;

namespace yp_learning_plugins.plugins.sample
{
    public class PreValidation : PluginBase
    {
        public PreValidation(string unsecureConfiguration, string secureConfiguration) : base(typeof(PreValidation))
        {
        }

        protected override void ExecuteDataversePlugin(ILocalPluginContext localPluginContext)
        {
            this.Trace(localPluginContext);

            var context = localPluginContext.PluginExecutionContext;

            if (context.InputParameters.Contains("Target") && context.InputParameters["Target"] is Entity)
            {

                var task = new Entity("task");
                task["subject"] = "VIA PROFILE";
                localPluginContext.PluginUserService.Create(task);
                localPluginContext.PluginAdminImpersonatedService.Create(task);


                var contact = (Entity)context.InputParameters["Target"];

                contact["firstname"] = contact.GetAttributeValue<string>("firstname").ToUpper();
                contact["lastname"] = contact.GetAttributeValue<string>("lastname").ToUpper();

                if (!contact.Contains("jobtitle") || string.IsNullOrEmpty(contact.GetAttributeValue<string>("jobtitle")))
                    throw new InvalidPluginExecutionException("❌JOBTITLE REQUIRED TO CREATE!!");

                // var task = new Entity("task");
                // task["subject"] = $"CRIADO VIA PG PRE-VALIDATION {contact.GetAttributeValue<string>("firstname")}";
                // task["ownerid"] = contact.GetAttributeValue<EntityReference>("ownerid");
                // localPluginContext.PluginUserService.Create(task);

                // throw new InvalidPluginExecutionException(OperationStatus.Failed, "EXCEÇÃO NA THREAD PRE-VALIDATION");
            }
        }

        private void Trace(ILocalPluginContext localPluginContext)
        {
            var context = localPluginContext.PluginExecutionContext;
            var trace = new StringBuilder();
            trace.AppendLine($"Depth: {context.Depth}");
            trace.AppendLine($"MessageName: {context.MessageName}");
            trace.AppendLine($"Stage :{context.Stage}");
            trace.AppendLine($"IsolationMode :{context.IsolationMode}");
            trace.AppendLine($"BusinessUnitId :{context.BusinessUnitId}");
            trace.AppendLine($"InitiatingUserId :{context.InitiatingUserId}");
            trace.AppendLine($"UserId :{context.UserId}");
            context.InputParameters.Select(s => trace.AppendLine($"{s.Key}: {s.Value}"));
            localPluginContext.TracingService.Trace(trace.ToString());
        }
    }
}
