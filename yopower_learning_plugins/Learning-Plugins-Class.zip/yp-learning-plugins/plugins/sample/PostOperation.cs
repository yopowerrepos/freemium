﻿using Microsoft.Xrm.Sdk;
using System;

namespace yp_learning_plugins.plugins.sample
{
    public class PostOperation : PluginBase
    {
        public PostOperation(string unsecureConfiguration, string secureConfiguration) : base(typeof(PreValidation))
        {
        }

        protected override void ExecuteDataversePlugin(ILocalPluginContext localPluginContext)
        {
            var context = localPluginContext.PluginExecutionContext;

            if (context.InputParameters.Contains("Target") && context.InputParameters["Target"] is Entity)
            {
                var contact = (Entity)context.InputParameters["Target"];

                var task = new Entity("task");
                task["subject"] = "CRIADO VIA PG PRE-OPERATION";
                task["regardingobjectid"] = contact.Contains("parentcustomerid") ? contact.GetAttributeValue<EntityReference>("parentcustomerid") : contact.ToEntityReference();
                localPluginContext.PluginUserService.Create(task);

                // throw new InvalidPluginExecutionException(OperationStatus.Failed, "EXCEÇÃO NA THREAD PRE-OPERATION");
            }
        }
    }
}

