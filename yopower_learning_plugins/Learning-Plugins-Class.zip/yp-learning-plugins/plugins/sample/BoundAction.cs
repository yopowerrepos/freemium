﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.Xml;
using System.Text;
using System.Threading.Tasks;
using yp_learning_plugins.earlybound;

namespace yp_learning_plugins.plugins.sample
{
    public class BoundAction : PluginBase
    {
        public BoundAction() : base(typeof(BoundAction))
        {
        }

        protected override void ExecuteDataversePlugin(ILocalPluginContext localPluginContext)
        {
            var context = localPluginContext.PluginExecutionContext;

            if (context.InputParameters.Contains("Target") && context.InputParameters["Target"] is EntityReference)
            {
                var refContact = (EntityReference)context.InputParameters["Target"];

                var random = new Random();

                context.OutputParameters["bool"] = true;
                context.OutputParameters["datetime"] = DateTime.Now;
                context.OutputParameters["decimal"] = Convert.ToDecimal(random.Next(1, 9999));
                context.OutputParameters["float"] = Convert.ToDouble(random.Next(1, 9999));
                context.OutputParameters["integer"] = random.Next(1, 9999);
                context.OutputParameters["string"] = $"{DateTime.Now.ToLongDateString()}";
            }
        }
    }
}