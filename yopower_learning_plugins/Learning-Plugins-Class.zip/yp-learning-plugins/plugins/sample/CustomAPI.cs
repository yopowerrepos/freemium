﻿using Microsoft.Xrm.Sdk;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;
using yp_learning_plugins.business.sample;
using yp_learning_plugins.statics;

namespace yp_learning_plugins.plugins.sample
{
    public class CustomAPI : PluginBase
    {
        public CustomAPI() : base(typeof(CustomAPI))
        {
        }

        protected override void ExecuteDataversePlugin(ILocalPluginContext localPluginContext)
        {
            var context = localPluginContext.PluginExecutionContext;

            var document = context.InputParameters["document"].ToString();
            var upsert = (bool)context.InputParameters["upsert"];

            try
            {
                var business = new CustomAPIBO(
                    localPluginContext.PluginUserService,
                    localPluginContext.PluginAdminImpersonatedService,
                    localPluginContext.NotificationService,
                    localPluginContext.TracingService,
                    localPluginContext.Logger);

                context.OutputParameters["data"] = JsonConvert.SerializeObject(business.GetCustomerData(document, upsert));
                context.OutputParameters["success"] = true;
                context.OutputParameters["message"] = string.Empty;
            }
            catch (Exception ex)
            {
                context.OutputParameters["data"] = "{}";
                context.OutputParameters["success"] = false;
                context.OutputParameters["message"] = ex.Message;
            }
        }
    }
}