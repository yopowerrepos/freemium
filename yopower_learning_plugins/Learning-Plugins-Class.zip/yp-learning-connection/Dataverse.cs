﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Tooling.Connector;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace yp_learning_connection
{
    public class Dataverse
    {
        //Constructor
        public Dataverse()
        {
            //AppConfig
            string appconfigPath = Path.GetDirectoryName(Path.GetDirectoryName(Path.GetDirectoryName(System.IO.Directory.GetCurrentDirectory())));
            var fileMap = new ExeConfigurationFileMap { ExeConfigFilename = Path.Combine(Path.GetFullPath($"{appconfigPath}\\{typeof(Dataverse).Namespace.Replace("_", "-")}\\app-sensitive.config")) };
            var config = ConfigurationManager.OpenMappedExeConfiguration(fileMap, ConfigurationUserLevel.None);
            var settings = config.AppSettings.Settings;

            string friendlyName = settings[this.friendlyName].Value.ToString();
            string url = settings[this.url].Value.ToString();
            string tenantid = settings[this.tenantid].Value.ToString();
            string applicationid = settings[this.applicationId].Value.ToString();
            string secret = settings[this.secret].Value.ToString();
            string user = settings[this.user].Value.ToString();
            string password = settings[this.password].Value.ToString();

            if (!string.IsNullOrEmpty(url) && !string.IsNullOrEmpty(user) && !string.IsNullOrEmpty(password))
                this.ServiceClient = UserPassword();
            else if (!string.IsNullOrEmpty(url) && !string.IsNullOrEmpty(tenantid) && !string.IsNullOrEmpty(applicationId) && !string.IsNullOrEmpty(secret))
                this.ServiceClient = ClientSecret();

            if (this.ServiceClient != null && this.ServiceClient.IsReady)
            {
                this.Records = new List<Entity>();
                this.PopulateDeleteSequence();
            }
            else
                throw new System.Exception(this.ServiceClient.LastCrmException.Message);

            CrmServiceClient ClientSecret()
            {
                string conn = $@"Url={url};
                            AuthType=ClientSecret;
                            TenantId={tenantid};
                            ClientId={applicationid};
                            ClientSecret={secret};
                            RequireNewInstance=True";

                return new CrmServiceClient(conn);
            }

            CrmServiceClient UserPassword()
            {
                string conn = $@"Url={url};
                            AuthType=Office365;
                            UserName={user};
                            Password={password};
                            RequireNewInstance=True";

                return new CrmServiceClient(conn);
            }
        }
        //Constantes
        public string friendlyName = "friendlyName";
        public string url = "url";
        public string tenantid = "tenantid";
        public string applicationId = "applicationid";
        public string secret = "secret";
        public string user = "user";
        public string password = "password";

        public enum eAuthType
        {
            UserPassword = 0,
            ClientSecret = 1
        }
        //Service
        public CrmServiceClient ServiceClient { get; private set; }

        //Registros criados durante os testes
        public List<Entity> Records { get; set; }

        public Queue<string> DeleteSequence { get; private set; }
        private void PopulateDeleteSequence()
        {
            this.DeleteSequence = new Queue<string>();
            //...
        }
        public void DeleteRecordsOnSequence()
        {
            foreach (var delete_ in DeleteSequence)
            {
                try
                {
                    foreach (var record_ in Records.Where(w => w.LogicalName == delete_))
                        ServiceClient.Delete(record_.LogicalName, record_.Id);
                }
                catch (Exception e) { throw new Exception(e.Message); }
            }
        }
    }

}
