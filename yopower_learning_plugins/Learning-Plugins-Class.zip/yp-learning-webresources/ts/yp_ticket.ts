namespace yp_ticket {

    declare var Xrm: any;

    export async function closeTicket(executionContext: any) {
        let id = executionContext.data.entity.getId().replace(/[{}]/g, "");

        let record: any = {};
        record.statecode = 1;
        record.statuscode = 2;

        return Xrm.WebApi.updateRecord("yp_ticket", id, record).then((_) => {
            this.refreshForm(id);
        }, (_) => {
            Xrm.Utility.closeProgressIndicator();
            var alertStrings = { text: _.message };
            var alertOptions = { height: 200, width: 400 };
            Xrm.Navigation.openAlertDialog(alertStrings, alertOptions).then((_) => { }, (_) => { });
        });
    }

    export async function refreshForm(id: string) {
        Xrm.Utility.closeProgressIndicator();
        let entityFormOptions: any = {};
        entityFormOptions["entityName"] = "yp_ticket";
        entityFormOptions["entityId"] = id;
        Xrm.Navigation.openForm(entityFormOptions).then((_) => { });
    }
}