﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System;
using yp_learning_connection;
using yp_learning_plugins;
using yp_learning_plugins.business;
using yp_learning_plugins.business.sample;
using yp_learning_plugins.earlybound;

namespace yp_learning_unittest
{
    [TestClass]
    public class Sample : Dataverse
    {
        [TestMethod]
        public void GetChecklistItems()
        {
            var business = new SubjectBO(this.ServiceClient, this.ServiceClient, null, null, null);
            var items = business.GetChecklistItems(new EntityReference(yp_subject.EntityLogicalName, new Guid("3baf0405-2520-ef11-840a-0022483630cc")));
        }

        [TestMethod]
        public void CreateTicketItems()
        {
            var target = new yp_ticket()
            {
                Id = new Guid("36cc3b1d-d54a-ef11-acce-002248def8f0"),
                yp_subjectid = new EntityReference(yp_subject.EntityLogicalName, new Guid("e2656725-2520-ef11-840a-0022483630cc"))
            };
            var business = new TicketBO(this.ServiceClient, this.ServiceClient, null, null, null);
            business.CreateTicketItems(target);
        }

        [TestMethod]
        public void GetTicketItems()
        {
            var business = new TicketBO(this.ServiceClient, this.ServiceClient, null, null, null);
            var items = business.GetTicketItems(new EntityReference(yp_ticket.EntityLogicalName, new Guid("7e315d58-d14a-ef11-acce-002248def8f0")));
        }

        [TestMethod]
        public void TestAI()
        {
            var target = this.ServiceClient.Retrieve(
                yp_ticket.EntityLogicalName,
                new Guid("b79b3b24-1e4a-ef11-acce-002248def8f0"),
                new ColumnSet(
                    yp_ticket.Fields.yp_description
                    )
                ).ToEntity<yp_ticket>();

            target.yp_request_reply = DateTime.Now;

            var business = new TicketBO(this.ServiceClient, this.ServiceClient, null, null, null);
            business.RequestAIReply(target, target);
        }

        [TestMethod]
        public void GetCustomerData()
        {
            var business = new CustomAPIBO(this.ServiceClient, this.ServiceClient, null, null, null);
            business.GetCustomerData("33000167000101");
        }

        [TestMethod]
        public void CreateTicketInfos()
        {
            var ticket = this.ServiceClient.Retrieve(
                yp_ticket.EntityLogicalName,
                new Guid("15a34f16-6d24-ef11-840a-0022483630cc"),
                new ColumnSet(true))
                .ToEntity<yp_ticket>();

            var business = new TicketBO(this.ServiceClient, this.ServiceClient, null, null, null);
            business.CreateTicketItems(ticket);
        }

        [TestMethod]
        public void GetTickets()
        {
            var business = new TicketBO(this.ServiceClient, this.ServiceClient, null, null, null);
            business.GetTickets("58E4A223CED35B51E9EFBFEC0E4A1FCF", this.ServiceClient.GetMyCrmUserId());
        }
    }
}