﻿using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Client;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.Collections.Generic;
using System.Linq;
using yp_learning_connection;
using yp_learning_plugins.earlybound;
using yp_learning_plugins.statics;

namespace yp_learning_console
{
    public class Sample
    {
        private Dataverse Dataverse { get; }

        public Sample(Dataverse dataverse)
        {
            this.Dataverse = dataverse;
        }

        public Guid Create()
        {
            var sample = new Entity("yp_sample");
            sample["yp_int_alternate_key"] = 0;
            sample["yp_st_string"] = "Texto";
            sample["yp_pl_optionset"] = new OptionSetValue(1);
            sample["yp_mpl_optionset"] = new OptionSetValueCollection() {
                new OptionSetValue(1),
                new OptionSetValue(3)
            };
            sample["yp_bo_twooptions"] = false;
            sample["yp_int_integer"] = 100;
            sample["yp_fl_float_number"] = 100.1d;
            sample["yp_dc_decimal"] = 100.2m;
            sample["yp_mn_money"] = new Money(100.3m);
            sample["yp_dt_datetime"] = DateTime.Now;
            sample["yp_lp_contactid"] = new EntityReference("contact", new Guid("9ec9b848-6120-ef11-840a-002248e00ac0"));
            sample["yp_lp_customerid"] = new EntityReference("account", new Guid("dcf3921c-6120-ef11-840a-002248e00ac0"));
            sample.Id = this.Dataverse.ServiceClient.Create(sample);
            return sample.Id;
        }

        public void UpdateWithId(Guid id)
        {
            var sample = new Entity("yp_sample", id);
            sample["yp_st_string"] = $"{DateTime.Now.ToShortDateString()}";
            sample["yp_pl_optionset"] = new OptionSetValue(2);
            this.Dataverse.ServiceClient.Update(sample);
        }

        public void UpdateWithAlternateKey(int alternateKey)
        {
            var sample = new Entity("yp_sample", "yp_int_alternate_key", alternateKey);
            sample["yp_st_string"] = "Atualizado via Chave Alternativa";
            this.Dataverse.ServiceClient.Update(sample);
        }

        public void Upsert(int chaveAlternativa)
        {
            var sample = new Entity("yp_sample", "yp_int_alternate_key", chaveAlternativa);
            sample["yp_st_string"] = "Criado/Atualizado via Upsert";

            var requisicao = new UpsertRequest()
            {
                Target = sample
            };

            var resposta = (UpsertResponse)this.Dataverse.ServiceClient.Execute(requisicao);
        }

        public void Delete(EntityReference refsample)
        {
            this.Dataverse.ServiceClient.Delete(refsample.LogicalName, refsample.Id);
        }

        public void Retrieve(Guid id)
        {
            Entity sample = this.Dataverse.ServiceClient.Retrieve(
                "yp_sample",
                id,
                new ColumnSet(
                    "yp_st_string",
                    "yp_pl_optionset",
                    "yp_mn_money",
                    "yp_lp_contactid")
                );

            var texto = sample.GetAttributeValue<string>("yp_st_string");
            var conjuntoDeOpcoes = sample.GetAttributeValue<OptionSetValue>("yp_pl_optionset");
            var moeda = sample.GetAttributeValue<Money>("yp_mn_money");
            var contato = sample.GetAttributeValue<EntityReference>("yp_lp_contactid");
        }

        public void RetrieveMultiple(int option)
        {
            var query = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                              <entity name='yp_sample'>
                                <attribute name='yp_sampleid' />
                                <attribute name='yp_st_string' />
                                <attribute name='yp_pl_optionset' />
                                <attribute name='yp_mn_money' />
                                <attribute name='yp_lp_contactid' />
                                <attribute name='createdby' />
                                <filter type='and'>
                                  <condition attribute='yp_pl_optionset' operator='eq' value='{option}' />
                                </filter>
                                <link-entity name='systemuser' from='systemuserid' to='createdby' visible='false' link-type='outer' alias='created_by'>
                                  <attribute name='businessunitid' alias='created_by.businessunit'/>
                                </link-entity>
                              </entity>
                            </fetch>";

            var results = this.Dataverse.ServiceClient.RetrieveMultiple(new FetchExpression(query));

            foreach (var sample_ in results.Entities)
            {
                var id = sample_.Id;
                var text = sample_.GetAttributeValue<string>("yp_st_string");
                var optionset = sample_.GetAttributeValue<OptionSetValue>("yp_pl_optionset");
                var money = sample_.GetAttributeValue<Money>("yp_mn_money");
                var contact = sample_.GetAttributeValue<EntityReference>("yp_lp_contactid");
                var businessUnitCreatedBy = new EntityReference();
                if (sample_.Contains("createdby"))
                    businessUnitCreatedBy = (EntityReference)sample_.GetAttributeValue<AliasedValue>("created_by.businessunit").Value;
            }
        }

        public void RetrieveMultipleWithHelper(List<int> alternateIds)
        {
            var query = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                              <entity name='{yp_sample.EntityLogicalName}'>
                                <attribute name='{yp_sample.Fields.Id}' />
                                {FetchHelper.InBuilder(yp_sample.Fields.yp_int_alternate_key, alternateIds.Select(s => s.ToString()).ToList())}
                              </entity>
                            </fetch>";

            var results = this.Dataverse.ServiceClient.RetrieveMultiple(new FetchExpression(query));
        }


        public void RetrieveMultipleAggregate()
        {
            var query = $@"<fetch version='1.0' output-format='xml-platform' aggregate='true'>
                              <entity name='yp_sample'>
                                <attribute name='yp_pl_optionset' alias='option' groupby='true'/>
                                <attribute name='yp_mn_money' alias='min' aggregate='min' />
                                <attribute name='yp_mn_money' alias='avg' aggregate='avg' />
                                <attribute name='yp_mn_money' alias='max' aggregate='max' />
                                <attribute name='yp_mn_money' alias='sum' aggregate='sum' />
                                <attribute name='yp_sampleid' alias='count' aggregate='count' distinct='true'/>
                                <attribute name='yp_sampleid' alias='countcolumn' aggregate='countcolumn' />
                              </entity>
                            </fetch>";

            var results = this.Dataverse.ServiceClient.RetrieveMultiple(new FetchExpression(query));

            foreach (var sample_ in results.Entities)
            {
                var option = (OptionSetValue)sample_.GetAttributeValue<AliasedValue>("option").Value;
                var min = ((Money)sample_.GetAttributeValue<AliasedValue>("min").Value).Value;
                var avg = ((Money)sample_.GetAttributeValue<AliasedValue>("avg").Value).Value;
                var max = ((Money)sample_.GetAttributeValue<AliasedValue>("max").Value).Value;
                var sum = ((Money)sample_.GetAttributeValue<AliasedValue>("sum").Value).Value;
                var count = (int)sample_.GetAttributeValue<AliasedValue>("count").Value;
                var countcolumn = (int)sample_.GetAttributeValue<AliasedValue>("countcolumn").Value;
                System.Console.WriteLine($"{option.Value} / MIN:{min} / AVG:{avg} / MAX:{max} / SUM:{sum} / COUNT:{count} / COLUMNS: {countcolumn}");
            }

            System.Console.ReadLine();
        }

        public enum eDateTimeGroupType
        {
            day = 1,
            week = 2,
            month = 3,
            year = 4,
            fiscal_period = 5,
            fiscal_year = 6
        }
        public void RetrieveMultipleAggregateDateTime(eDateTimeGroupType aggregator, bool userTimeZone = true)
        {
            var query = $@"<fetch aggregate='true'>
                            <entity name='yp_sample'>
                            <attribute name='yp_dt_datetime' usertimezone='{userTimeZone.ToString().ToLower()}' alias='date' groupby='true' dategrouping='{aggregator.ToString().Replace("_", "-")}' />
                            <attribute name='yp_mn_money' alias='sum' aggregate='sum' />
                            <order alias='date' />
                            </entity>
                        </fetch>";

            var results = this.Dataverse.ServiceClient.RetrieveMultiple(new FetchExpression(query));

            foreach (var sample_ in results.Entities)
            {
                var alias = sample_.GetAttributeValue<AliasedValue>("date");
                object date = null;
                if (alias != null && alias.Value != null)
                {
                    if (alias.Value.GetType() == typeof(int))
                        date = (int)alias.Value;
                    else if (alias.Value.GetType() == typeof(string))
                        date = (string)alias.Value;
                }
                var sum = ((Money)sample_.GetAttributeValue<AliasedValue>("sum").Value).Value;
                System.Console.WriteLine($"DATE:{date} / SUM:{sum}");
            }

            System.Console.ReadLine();
        }

        public void RetrieveMultipleRowAggregate()
        {
            // Alternate Key 10.000
            var sample = new Guid("b15b62bb-6420-ef11-840a-0022483630cc");

            /* Operators
             * above                            Returns all records in referenced record's hierarchical ancestry line.
             * eq-or-above                      Returns the referenced record and all records above it in the hierarchy.
             * under                            Returns all child records below the referenced record in the hierarchy
             * eq-or-under                      Returns the referenced record and all child records below it in the hierarchy
             * not-under                        Returns all records not below the referenced record in the hierarchy
             * eq-useroruserhierarchy           When hierarchical security models are used, Equals current user or user's reporting hierarchy
             * eq-useroruserhierarchyandteams   When hierarchical security models are used, Equals current user and user's teams, or user's reporting hierarchy and their teams
             */

            /* Structure
             * 10.000
             * - 10.001
             *  - 10.002
             *  - 10.003
             *  - 10.004
             * - 10.005
             *  - 10.006
             *  - 10.007
             * - 10.008
             * - 10.009
             *  - 10.010
             */

            var query = $@"<fetch distinct='false' no-lock='false' mapping='logical' >  
                          <entity name='yp_sample'>  
                            <attribute name='yp_sampleid' />  
                            <attribute name='yp_st_string' />  
                            <attribute name='yp_sampleid' rowaggregate='CountsChildren' alias='children'/>  
                            <filter type='and'>  
                              <condition attribute='yp_sampleid' operator='under' value='{sample}' />
                            </filter>  
                          </entity>  
                        </fetch>";

            var results = this.Dataverse.ServiceClient.RetrieveMultiple(new FetchExpression(query));

            foreach (var sample_ in results.Entities)
            {
                var label = sample_.GetAttributeValue<string>("yp_st_string");
                var children = (int)sample_.GetAttributeValue<AliasedValue>("children").Value;
                System.Console.WriteLine($"{label}: {children}");
            }

            System.Console.ReadLine();
        }

        public void RetrieveMultipleValueOf()
        {
            // Money = R$ 1,00
            // Decimal = 1,00

            var query = $@"<fetch distinct='false' no-lock='false' mapping='logical' >  
                          <entity name='yp_sample'>  
                            <attribute name='yp_sampleid' />  
                            <filter type='and'>  
                              <condition attribute='yp_mn_money' operator='eq' valueof='yp_dc_decimal' />
                            </filter>  
                          </entity>  
                        </fetch>";

            var results = this.Dataverse.ServiceClient.RetrieveMultiple(new FetchExpression(query));
            System.Console.ReadLine();
        }

        public void RetrieveMultipleHintUnion()
        {
            // https://www.linkedin.com/posts/vinnybasile_filter-or-link-type-any-activity-7198810145621991425-MeM-?utm_source=share&utm_medium=member_desktop
        }


        public void Linq()
        {
            using (var context = new OrganizationServiceContext(this.Dataverse.ServiceClient))
            {
                var samples = (from m_ in context.CreateQuery("yp_sample")
                               where m_["yp_int_integer"] != null && (Int32)m_["yp_int_integer"] > 2500
                               select new
                               {
                                   Id = m_.Id,
                                   Texto = m_.Contains("yp_st_string") ? m_["yp_st_string"] : "NÃO TEM VALOR",
                                   Inteiro = m_["yp_int_integer"]
                               }).ToList();

                foreach (var sample_ in samples)
                {
                    // ....
                }
            }
        }

        public void Lambda()
        {
            using (var context = new OrganizationServiceContext(this.Dataverse.ServiceClient))
            {
                var samples = context.CreateQuery("yp_sample")
                                    .Where(w => (Int32)w["yp_int_integer"] < 500
                                        && (OptionSetValue)w["yp_pl_optionset"] != null
                                        && (OptionSetValue)w["yp_pl_optionset"] == new OptionSetValue(1))
                                    .Select(s => new
                                    {
                                        Id = s.Id,
                                        Texto = s["yp_st_string"],
                                        Inteiro = s["yp_int_integer"]
                                    }).ToList();

                foreach (var sample_ in samples)
                {
                    // ....
                }
            }
        }

        public EntityCollection QueryExpression()
        {
            QueryExpression query = new QueryExpression("yp_sample");
            query.ColumnSet.AddColumns("yp_st_string", "yp_int_integer");
            FilterExpression filter = new FilterExpression();

            ConditionExpression condition = new ConditionExpression();
            condition.AttributeName = "statecode";
            condition.Operator = ConditionOperator.Equal;
            condition.Values.Add(1);
            filter.Conditions.Add(condition);

            query.Criteria.AddFilter(filter);

            EntityCollection results = this.Dataverse.ServiceClient.RetrieveMultiple(query);

            return results;
        }

        public void FetchXmlToQueryExp()
        {
            var query = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                              <entity name='yp_sample'>
                                <attribute name='yp_sampleid' />
                                <attribute name='yp_st_string' alias='text'/>
                                <attribute name='yp_pl_optionset' />
                                <attribute name='yp_mn_money' />
                                <attribute name='yp_lp_contactid' />
                                <attribute name='createdby' />
                                <filter type='and'>
                                  <condition attribute='yp_pl_optionset' operator='eq' value='1' />
                                </filter>
                                <link-entity name='systemuser' from='systemuserid' to='createdby' visible='false' link-type='outer' alias='created_by'>
                                  <attribute name='businessunitid' alias='created_by.businessunit'/>
                                </link-entity>
                              </entity>
                            </fetch>";
            var requisicao = new FetchXmlToQueryExpressionRequest()
            {
                FetchXml = query
            };
            var resposta = (FetchXmlToQueryExpressionResponse)this.Dataverse.ServiceClient.Execute(requisicao);

            var alias = resposta.Query.ColumnSet.AttributeExpressions.Where(w => w.Alias == "text").ToList();
        }

        public void ExecuteTransaction()
        {
            var transacao = new ExecuteTransactionRequest()
            {
                Requests = new OrganizationRequestCollection()
            };

            var id = Guid.NewGuid();

            // ✅ Contato
            transacao.Requests.Add(new CreateRequest()
            {
                Target = new Entity("contact")
                {
                    Id = id,
                    Attributes =
                    {
                        { "firstname", "CONTATO" },
                        { "lastname", "BY TRANSATION" }
                    }
                }
            });

            // ✅ sample Relacionado ao Contato (Chave Alternativa - Integer)
            transacao.Requests.Add(new CreateRequest()
            {
                Target = new Entity("yp_sample")
                {
                    Attributes =
                    {
                        { "yp_int_alternate_key", 6001 },
                        { "yp_lp_customerid", new EntityReference("contact", id) }
                    }
                }
            });

            // ❎ sample (Chave Alternatva - String)
            transacao.Requests.Add(new CreateRequest()
            {
                Target = new Entity("yp_sample")
                {
                    Attributes =
                    {
                        { "yp_int_alternate_key", 6002 }
                    }
                }
            });

            // ❎ sample (Chave Alternatva - Integer, Atributo que não existe)
            transacao.Requests.Add(new CreateRequest()
            {
                Target = new Entity("yp_sample")
                {
                    Attributes =
                    {
                        { "yp_int_alternate_key", 6003 },
                    }
                }
            });

            this.Dataverse.ServiceClient.Execute(transacao);
        }

        public void ExecuteMultiple()
        {
            var requisicao = new ExecuteMultipleRequest()
            {
                Settings = new ExecuteMultipleSettings()
                {
                    ContinueOnError = true,
                    ReturnResponses = true,
                },
                Requests = new OrganizationRequestCollection()
            };

            for (int i = 9000; i < 9051; i++)
            {
                var sample = new Entity("yp_sample");
                sample["yp_int_alternate_key"] = i;
                var criar = new CreateRequest()
                {
                    Target = sample
                };
                requisicao.Requests.Add(criar);

                if (requisicao.Requests.Count >= 25)
                {
                    this.Dataverse.ServiceClient.Execute(requisicao);
                    requisicao.Requests.Clear();
                }
            }
        }

        public Guid CreateEarlybound()
        {
            var sample = new yp_sample();
            sample.yp_int_alternate_key = 10;
            sample.yp_st_string = "Texto";
            sample.yp_pl_optionset = yp_sample_yp_pl_optionset.OptionB;
            sample.yp_mpl_optionset = new List<yp_sample_yp_mpl_optionset>() {
                yp_sample_yp_mpl_optionset.Option1,
                yp_sample_yp_mpl_optionset.Option2,
                yp_sample_yp_mpl_optionset.Option3
            };
            sample.yp_bo_twooptions = false;
            sample.yp_int_integer = 100;
            sample.yp_fl_float_number = 100.1d;
            sample.yp_dc_decimal = 100.2m;
            sample.yp_mn_money = new Money(100.3m);
            sample.yp_dt_datetime = DateTime.Now;
            sample.yp_lp_contactid = new EntityReference("contact", new Guid("9ec9b848-6120-ef11-840a-002248e00ac0"));
            sample.yp_lp_customerid = new EntityReference("account", new Guid("dcf3921c-6120-ef11-840a-002248e00ac0"));
            return this.Dataverse.ServiceClient.Create(sample);
        }

        public void CreateMultipleWithParameters()
        {
            var request = new CreateMultipleRequest()
            {
                Targets = new EntityCollection(),
                Parameters =
                {
                    { "CustomParam1", 1 },
                    { "CustomParam2", "2" }
                }
            };
            this.Dataverse.ServiceClient.Execute(request);
        }
    }
}
