﻿using System.Collections.Generic;
using yp_learning_connection;
using yp_learning_plugins.earlybound;

namespace yp_learning_console
{
    public class Program
    {
        static void Main(string[] args)
        {
            var dataverse = new Dataverse();
            var examples = new Sample(dataverse);
            // var id = examples.Create();
            // examples.UpdateWithId(id);
            // examples.UpdateWithAlternateKey(14812);
            // examples.UpdateWithAlternateKey(14813);
            // examples.UpdateWithAlternateKey(14814);
            // examples.Upsert(6000);
            // examples.Upsert(0);
            // examples.Retrieve(new System.Guid("7af90767-6520-ef11-840a-6045bd39cc43"));
            // examples.Retrieve(new System.Guid("7af90767-6520-ef11-840a-000000000000"));
            // examples.RetrieveMultiple(1);
            examples.RetrieveMultipleWithHelper(new List<int>() { 9040 });
            // examples.RetrieveMultipleAggregate();
            // examples.RetrieveMultipleAggregateDateTime(Sample.eDateTimeGroupType.week, false);
            // examples.Linq();
            // examples.Lambda();
            // examples.QueryExpression();
            // examples.FetchXmlToQueryExp();
            // examples.ExecuteTransaction();
            // examples.ExecuteMultiple();
            // examples.CreateEarlybound();
        }
    }
}
